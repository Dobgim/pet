document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('addPuppyForm');
  const tableBody = document.getElementById('adminPuppyTableBody');

  if (typeof supabaseClient === 'undefined') {
    alert("CRITICAL ERROR: Supabase is not initialized. Check your network or supabase-client.js");
    return;
  }

  // Load data from Supabase
  async function renderTable() {
    tableBody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 2rem;"><i class="fas fa-spinner fa-spin"></i> Fetching from database...</td></tr>';

    try {
      const { data: puppies, error } = await supabaseClient
        .from('puppies')
        .select('*')
        .order('id', { ascending: false }); // show latest entries top

      if (error) throw error;

      tableBody.innerHTML = '';

      if (!puppies || puppies.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 2rem;">No puppies found in database. Add one!</td></tr>';
        return;
      }

      puppies.forEach((puppy) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${puppy.id}</td>
          <td><img src="${puppy.image_url}" alt="${puppy.breed}"></td>
          <td><strong>${puppy.tracking_code}</strong></td>
          <td>${puppy.name || '-'}</td>
          <td>${puppy.breed}</td>
          <td>$${parseInt(puppy.price).toLocaleString()}</td>
          <td>${puppy.gender}</td>
          <td>
            <button class="action-btn" onclick="deletePuppy('${puppy.id}')" title="Remove">
              <i class="fas fa-trash-alt"></i>
            </button>
          </td>
        `;
        tableBody.appendChild(tr);
      });
    } catch(err) {
      console.error(err);
      const msg = err.message || "Unknown error connecting to database";
      tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2rem; color:red;">
        <i class="fas fa-exclamation-triangle"></i> Database Error: ${msg}<br>
        <small>Please ensure the "puppies" table exists in Supabase with the correct columns.</small>
      </td></tr>`;
    }
  }

  // Handle Form Submit to Supabase
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
    submitBtn.disabled = true;
    
    const fileInput = document.getElementById('image_file');
    const file = fileInput.files[0];

    if (!file) {
      alert("Please select an image");
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      return;
    }

    try {
      // 1. Upload image to Supabase Storage
      const fileName = `${Date.now()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabaseClient.storage
        .from('puppy-images')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // 2. Get public URL
      const { data: urlData } = supabaseClient.storage
        .from('puppy-images')
        .getPublicUrl(uploadData.path);

      const imageUrl = urlData.publicUrl;

      // 3. Generate Tracking Code
      const trackingCode = "TRK" + Math.floor(Math.random() * 1000000);

      const newPuppy = {
        name: document.getElementById('pName').value,
        breed: document.getElementById('pBreed').value,
        age: document.getElementById('pAge').value,
        gender: document.getElementById('pGender').value,
        price: parseInt(document.getElementById('pPrice').value),
        tracking_code: trackingCode,
        image_url: imageUrl
      };

      const { data, error } = await supabaseClient
        .from('puppies')
        .insert([newPuppy]);
        
      if (error) throw error;
      
      form.reset();
      await renderTable();
      alert(`Puppy posted successfully! Tracking Code: ${trackingCode}`);
    } catch(err) {
      console.error(err);
      alert("Error processing request: " + err.message);
    } finally {
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    }
  });

  // Expose delete to window so inline onclick can use it
  window.deletePuppy = async function(id) {
    if(confirm("Are you sure you want to completely remove this puppy from the database?")) {
      try {
        const { error } = await supabaseClient
          .from('puppies')
          .delete()
          .eq('id', parseInt(id));
          
        if (error) throw error;
        
        await renderTable();
      } catch(err) {
        console.error(err);
        alert("Error deleting puppy: " + err.message);
      }
    }
  };

  // Deprecated since real DB
  window.clearData = function() {
    alert("Warning: Quick factory reset is disabled when connected to a live database. Please delete rows manually.");
  };

  // Initial render
  renderTable();
});
