// Supabase Configuration
const SUPABASE_URL = 'https://dktfwvvdvziljwiakpdo.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRrdGZ3dnZkdnppbGp3aWFrcGRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4OTY1MDksImV4cCI6MjA4OTQ3MjUwOX0.Ec9DfVGSDxxQzWzOXBakn_9fMqFWcBSpO_aYCCYqydg';

// Initialize the Supabase client
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
